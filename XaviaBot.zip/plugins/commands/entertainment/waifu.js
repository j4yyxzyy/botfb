export default function ({ message }) {
    global.random(0, 5) === 3 ? message.reply("Love you bakaaa >w<") : message.reply("We are just friends 😔");
}
